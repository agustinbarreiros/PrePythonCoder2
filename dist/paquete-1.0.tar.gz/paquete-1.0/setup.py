from setuptools import setup


setup ( 
    name="paquete",
    version="1.0",
    packages=["paquete"],
    author="Agustin Barreiros",
    author_email="mailfalso@hotmail.com",
    description="Paquete para modelar clientes",
)